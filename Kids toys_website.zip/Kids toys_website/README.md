# clg-html-css-js-template
Boilerplate HTML project for CLG Foundations of Web Dev course
